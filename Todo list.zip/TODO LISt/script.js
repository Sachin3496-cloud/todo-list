function addTask() {
    let taskInput = document.getElementById('taskInput');
    let taskText = taskInput.value.trim();
    if (taskText === '') return;
    
    let li = document.createElement('li');
    let taskSpan = document.createElement('span');
    taskSpan.textContent = taskText;
    
    let buttonDiv = document.createElement('div');
    buttonDiv.classList.add('buttons');
    
    let editButton = document.createElement('button');
    editButton.classList.add('edit');
    editButton.textContent = 'Edit';
    editButton.onclick = function() { editTask(editButton); };
    
    let deleteButton = document.createElement('button');
    deleteButton.classList.add('delete');
    deleteButton.textContent = 'Delete';
    deleteButton.onclick = function() { deleteTask(deleteButton); };
    
    buttonDiv.appendChild(editButton);
    buttonDiv.appendChild(deleteButton);
    
    li.appendChild(taskSpan);
    li.appendChild(buttonDiv);
    document.getElementById('taskList').appendChild(li);
    taskInput.value = '';
}

function editTask(button) {
    let li = button.parentElement.parentElement;
    let taskSpan = li.querySelector('span');
    let newText = prompt('Edit Task:', taskSpan.textContent);
    if (newText !== null && newText.trim() !== '') {
        taskSpan.textContent = newText.trim();
    }
}

function deleteTask(button) {
    let li = button.parentElement.parentElement;
    li.remove();
}